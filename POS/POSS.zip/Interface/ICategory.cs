﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using POSS.ViewModel;

namespace POSS.Interface
{
    public interface ICategory
    {
        List<CategoryModel> GetCategoriesDetail();
        CategoryModel GetCategoryById(int id);
        bool InsertCategory(CategoryModel category);
        bool DeleteCategory(int? id);
    }
}
