﻿var app = angular.module("MyRestoApp", [])
	.controller("MyRestoController", function () {

	})