﻿app.controller("TableController", function ($scope, $http, Table_Service) {

	angular.element(document).ready(function () {
		
		if (GlobId != 0) {
			$scope.CallHome(GlobId);
		};
	});
	$scope.AllTables = [];
	$scope.CallHome = function (id) {
		Table_Service.getTables(id).then((response) => {
			$scope.AllTables = response.data;
			
		});
	};
	$scope.loadTable = function (id) {
		
	};
	//$scope.$on('ngRepeatFinished', function (ngRepeatFinishedEvent) {
	//	debugger
	//});
});