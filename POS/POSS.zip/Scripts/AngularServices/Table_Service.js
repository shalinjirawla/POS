﻿app.factory("Table_Service", function ($http) {

	var service = {};

	service.getTables = function (id) {
		return $http.get("/api/Table/GetTableByRoomID/", { params: {"id":id}});
	};
	//service.loadTable = function (id) {
	//	return $http.get("/api/Room/GetSelectedTable/", { params: { "id": id } });
	//};
	return service;
});